#ifndef GOOGLE_H
#define GOOGLE_H

#include <iostream>
#include <string>
using namespace std;
#include <Windows.h>
#include <stdio.h>
#include "shared.h"
#include "ts3_functions.h"

int google(struct TrackInfo *info, struct TS3Functions ts3Functions);

#endif //#ifndef GOOGLE_H