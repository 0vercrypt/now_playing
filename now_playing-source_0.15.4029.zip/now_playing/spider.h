#ifndef SPIDER_H
#define SPIDER_H

#include <Windows.h>
#include <stdio.h>
#include "shared.h"
#include "ts3_functions.h"

int spider(struct TrackInfo *info, struct TS3Functions ts3Functions);

#endif //#ifndef LIGHTALLOY_H