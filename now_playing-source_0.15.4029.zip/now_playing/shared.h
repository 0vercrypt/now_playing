#ifndef SHARED_H
#define SHARED_H

struct TrackInfo {
	char chTitle[1024];
	char *chProgramm;
};

#endif